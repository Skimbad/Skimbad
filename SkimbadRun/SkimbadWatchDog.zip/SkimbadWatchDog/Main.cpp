
#include <Windows.h>
#include <time.h>
#include <mmsystem.h>
#include "Comms.h"

int WINAPI WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow)
{

	srand((unsigned int)time(NULL));
	int WDID = rand(); //Random ID for verification
	int WDSpot = -1; //Position in array

	HANDLE hMapFile;
	MMStatusHeader *mmStatus;

	if (CreateSkimMap(hMapFile, mmStatus))
	{
		MessageBox(NULL, L"Memory Map Creation Failed.", L"Skimbad", MB_OK | MB_ICONERROR);
		return 0;
	}
	
	//Choose which watchdog spot to run in
	for (int x = 0; (x < WD_MAX) && (WDSpot == -1); x++)
	{
		//1/2 seconds since last update take this spot
		if (timeGetTime() - mmStatus->WD[x].LastUpdate > 500)
		{
			WDSpot = x;
			mmStatus->WD[x].WDID = WDID;
			mmStatus->WD[x].LastUpdate = timeGetTime();
		}
	}

	//all slots taken
	if (WDSpot == -1)
	{
		return 0;
	}

	int done = 0;
	while ((mmStatus->SettingsCommand != WD_KILL_ALL) && !done)
	{
		//monitor status of main application

		//Not updated for 1/2 seconds
		if (timeGetTime() - mmStatus->LastUpdate > 500)
		{
			//if main is not being launched
			if (!mmStatus->Loading)
			{
				mmStatus->Loading = 1;

				//launch it
				ShellExecute(NULL, L"open", L"SkimbadRun.exe", NULL, NULL, SW_SHOW);
				
			}

		}

		Sleep(100);

		//check that this WD is the right one for its slot
		if (mmStatus->WD[WDSpot].WDID != WDID)
		{
			//Another watchdog took my spot
			done = 1;
		}
		else
		{
			//update time
			mmStatus->WD[WDSpot].LastUpdate = timeGetTime();
		}
	}

	CloseSkimMap(hMapFile, mmStatus);

	return 0;
}