
#include <Windows.h>
#include <TlHelp32.h>
#include <mmsystem.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <locale>
#include <codecvt>
#include <istream>
#include <sstream>

#include "resource.h"
#include "Comms.h"


#define MAX_DATA_SIZE 300

//Check and launch watchdogs
void WatchDogCheck(MMStatusHeader * mmStatus)
{

	for (int i = 0; i < WD_MAX; i++)
	{
		//if no responce for 3 seconds launch
		if ((timeGetTime() - mmStatus->WD[i].LastUpdate) > 500)
		{
			ShellExecute(NULL, L"open", L"SkimbadWatchDog.exe", NULL, NULL, SW_SHOW);
		}
	}
}

DWORD FindExePid(WCHAR * exeName)
{
	HANDLE ProcessSnap;
	PROCESSENTRY32 pe32;
	//int nIndex;

	pe32.dwSize = sizeof(PROCESSENTRY32);
	ProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

	if (Process32First(ProcessSnap, &pe32))
	{
		do
		{
			if (wcscmp(pe32.szExeFile, exeName) == 0)
			{
				return pe32.th32ProcessID;
			}

		} while (Process32Next(ProcessSnap, &pe32));

	}
	else
	{
		LPTSTR errorstring = NULL;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&errorstring, 0, NULL);
		MessageBox(NULL, errorstring, errorstring, MB_OK | MB_ICONERROR);
		free(errorstring);
		return 0;
	}

	return 0;
}

std::wstring s2ws(const std::string& str)
{
	typedef std::codecvt_utf8<wchar_t> convert_typeX;
	std::wstring_convert<convert_typeX, wchar_t> converterX;

	return converterX.from_bytes(str);
}

std::string ws2s(const std::wstring& wstr)
{
	typedef std::codecvt_utf8<wchar_t> convert_typeX;
	std::wstring_convert<convert_typeX, wchar_t> converterX;

	return converterX.to_bytes(wstr);
}


/* Generate card data in remote memory. A more complicated
*  method may be needed in the future.
*/
void GenerateCardDataW(HANDLE hProcess, WCHAR* lpBaseAddress, std::vector<std::string> &firstnames, std::vector<std::string> &lastnames)
{
	int luhnsum = 0;	// Running digit total for checksum digit
	int offset = 0;		// Current memory offset
	WCHAR* buf;			// String data
	WCHAR* buf2;			// String data
	int numbers[18];	// Card numbers

	buf = (WCHAR *)malloc(sizeof(WCHAR) * MAX_DATA_SIZE);
	buf2 = (WCHAR *)malloc(sizeof(WCHAR) * MAX_DATA_SIZE);

	numbers[0] = rand() % 3 + 4; //4, 5, or 6 for first digit
	luhnsum += ((numbers[0] * 2) / 10) + ((numbers[0] * 2) % 10);


	//Generate 14 more numbers. Last number is checksum.
	//luhn checksum built in for a 16 digit card number
	for (int x = 1; x < 15; x++)
	{
		if (x % 2 == 0)
		{
			numbers[x] = rand() % 10;
			luhnsum += ((numbers[x] * 2) / 10) + ((numbers[x] * 2) % 10);
		}
		else
		{
			numbers[x] = rand() % 10;
			luhnsum += numbers[x];
		}
	}

	//add checksum
	numbers[15] = (luhnsum * 9) % 10;

	time_t t = time(0);
	t += (rand() % (12 * 4)) * 60 * 60 * 24 * 31; //add some months
	struct tm fut;
	localtime_s(&fut, &t);
	//year
	numbers[16] = (fut.tm_year % 100);

	//month
	numbers[17] = (fut.tm_mon);

	//Write track start data
	WriteProcessMemory(hProcess, lpBaseAddress, L"%B", sizeof(WCHAR) * 2, NULL);
	offset += 2;

	//write as characters to remote memory
	for (int x = 0; x < 16; x++)
	{
		swprintf(buf, sizeof(WCHAR) * MAX_DATA_SIZE, L"%d", numbers[x]);
		WriteProcessMemory(hProcess, lpBaseAddress + offset + x, buf, sizeof(WCHAR), NULL);
	}
	offset += 16;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, L"^", sizeof(WCHAR) * 1, NULL);
	offset++;

	std::wstring lname;
	lname = s2ws(lastnames[rand() % lastnames.size()]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, lname.c_str(), sizeof(WCHAR) * lname.size(), NULL);
	offset += lname.size();

	WriteProcessMemory(hProcess, lpBaseAddress + offset, L"/", sizeof(WCHAR) * 1, NULL);
	offset++;

	std::wstring fname;
	fname = s2ws(firstnames[rand() % firstnames.size()]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, fname.c_str(), sizeof(WCHAR) * fname.size(), NULL);
	offset += fname.size();

	WriteProcessMemory(hProcess, lpBaseAddress + offset, L"^", sizeof(WCHAR) * 1, NULL);
	offset++;

	swprintf(buf, sizeof(WCHAR) * MAX_DATA_SIZE, L"%02d%02d", numbers[16], numbers[17]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, buf, sizeof(WCHAR) * 4, NULL);
	offset += 4;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, L"1010000000000000005?;", sizeof(WCHAR) * 21, NULL);
	offset += 21;

	for (int x = 0; x < 16; x++)
	{
		swprintf(buf, sizeof(WCHAR) * MAX_DATA_SIZE, L"%d", numbers[x]);
		WriteProcessMemory(hProcess, lpBaseAddress + offset + x, buf, sizeof(WCHAR), NULL);
	}
	offset += 16;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "=", sizeof(char) * 1, NULL);
	offset += 1;

	swprintf(buf, sizeof(WCHAR) * MAX_DATA_SIZE, L"%02d%02d", numbers[16], numbers[17]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, buf, sizeof(WCHAR) * 4, NULL);
	offset += 4;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, L"10100000000005?", sizeof(WCHAR) * 21, NULL);

	//A check to make sure it has written properly
	ReadProcessMemory(hProcess, lpBaseAddress, buf2, sizeof(WCHAR) * MAX_DATA_SIZE, NULL);
	wprintf(L"U Card - %s\n", buf2);

	free(buf);
	free(buf2);
}

/* Generate card data in remote memory. A more complicated
*  method may be needed in the future.
*/
void GenerateCardDataA(HANDLE hProcess, char* lpBaseAddress, std::vector<std::string> &firstnames, std::vector<std::string> &lastnames)
{
	int luhnsum = 0;	// Running digit total for checksum digit
	int offset = 0;		// Current memory offset
	char* buf;			// String data
	char* buf2;			// String data
	int numbers[18];	// Card numbers

	buf = (char *)malloc(sizeof(char) * MAX_DATA_SIZE);
	buf2 = (char *)malloc(sizeof(char) * MAX_DATA_SIZE);

	numbers[0] = rand() % 3 + 4; //4, 5, or 6 for first digit
	luhnsum += ((numbers[0] * 2) / 10) + ((numbers[0] * 2) % 10);

	//Generate 14 more numbers. Last number is checksum.
	//luhn checksum built in for a 16 digit card number
	for (int x = 1; x < 15; x++)
	{
		if (x % 2 == 0)
		{
			numbers[x] = rand() % 10;
			luhnsum += ((numbers[x] * 2) / 10) + ((numbers[x] * 2) % 10);
		}
		else
		{
			numbers[x] = rand() % 10;
			luhnsum += numbers[x];
		}
	}

	//add checksum
	numbers[15] = (luhnsum * 9) % 10;

	//Random expiration date
	time_t t = time(0);
	t += (rand() % (12 * 4)) * 60 * 60 * 24 * 31; //add some approximate random months
	struct tm fut;
	localtime_s(&fut, &t);
	//year
	numbers[16] = (fut.tm_year % 100);

	//month
	numbers[17] = (fut.tm_mon);

	//Write track start data
	WriteProcessMemory(hProcess, lpBaseAddress, "%B", sizeof(char) * 2, NULL);
	offset += 2;

	//write as characters to remote memory
	for (int x = 0; x < 16; x++)
	{
		sprintf_s(buf, sizeof(char) * MAX_DATA_SIZE, "%d", numbers[x]);
		WriteProcessMemory(hProcess, lpBaseAddress + offset + x, buf, sizeof(char), NULL);
	}
	offset += 16;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "^", sizeof(char) * 1, NULL);
	offset++;

	std::string name;
	name = lastnames[rand() % lastnames.size()];
	WriteProcessMemory(hProcess, lpBaseAddress + offset, name.c_str(), sizeof(char) * name.size(), NULL);
	offset += name.size();

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "/", sizeof(char) * 1, NULL);
	offset++;

	name = firstnames[rand() % firstnames.size()];
	WriteProcessMemory(hProcess, lpBaseAddress + offset, name.c_str(), sizeof(char) * name.size(), NULL);
	offset += name.size();

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "^", sizeof(char) * 1, NULL);
	offset++;


	sprintf_s(buf, sizeof(char) * MAX_DATA_SIZE, "%02d%02d", numbers[16], numbers[17]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, buf, sizeof(char) * 4, NULL);
	offset += 4;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "1010000000000000005?;", sizeof(char) * 21, NULL);
	offset += 21;

	for (int x = 0; x < 16; x++)
	{
		sprintf_s(buf, sizeof(char) * MAX_DATA_SIZE, "%d", numbers[x]);
		WriteProcessMemory(hProcess, lpBaseAddress + offset + x, buf, sizeof(char), NULL);
	}
	offset += 16;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "=", sizeof(char) * 1, NULL);
	offset += 1;

	sprintf_s(buf, sizeof(char) * MAX_DATA_SIZE, "%02d%02d", numbers[16], numbers[17]);
	WriteProcessMemory(hProcess, lpBaseAddress + offset, buf, sizeof(char) * 4, NULL);
	offset += 4;

	WriteProcessMemory(hProcess, lpBaseAddress + offset, "10100000000005?", sizeof(char) * 21, NULL);

	//A check to make sure it has written properly
	ReadProcessMemory(hProcess, lpBaseAddress, buf2, sizeof(char) * MAX_DATA_SIZE, NULL);
	printf("A Card - %s\n", buf2);

	free(buf);
	free(buf2);
}

void LoadNames(char * filename, std::vector<std::string> &names)
{
	std::ifstream inf(filename);

	std::string line;

	while (std::getline(inf, line))
	{
		names.push_back(line);
	}
}

//Added status header do to time consumption
void LoadNamesRC(int textresource, std::vector<std::string> &names)
{
	HRSRC hRes = FindResource(GetModuleHandle(NULL), MAKEINTRESOURCE(textresource), L"text");
	DWORD dwSize = SizeofResource(GetModuleHandle(NULL), hRes);
	HGLOBAL hGlob = LoadResource(GetModuleHandle(NULL), hRes);
	const BYTE* pData = reinterpret_cast<const BYTE*>(::LockResource(hGlob));

	std::string tmp((char *)pData);
	std::istringstream tstream(tmp);

	std::string line;

	while (std::getline(tstream, line))
	{
		names.push_back(line);
	}
}

int WINAPI WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow)
{

	WCHAR szPName[MAX_PATH];
	DWORD dwNumCardsPerSec;
	DWORD dwPid;
	DWORD dwCardsPerTic;

	HANDLE hMapFile;
	MMStatusHeader *mmStatus;

	if (CreateSkimMap(hMapFile, mmStatus))
	{
		MessageBox(NULL, L"Memory Map Creation Failed.", L"Skimbad", MB_OK | MB_ICONERROR);
		return 0;
	}

	//Allow for 1/2 seconds since last update
	if (timeGetTime() - mmStatus->LastUpdate < 500)
	{
		//MessageBox(NULL, L"Skimbad is already running", L"Skimbad", MB_OK | MB_ICONERROR);
		return 0;
	}
	else
	{
		//Reset anything if still there
		mmStatus->SettingsCommand = 0;
	}

	//Set update time and notify done loading
	mmStatus->LastUpdate = timeGetTime();
	mmStatus->Loading = 0;

	//Load registry settings
	HKEY hkey;
	LSTATUS stat;

	stat = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Skimbad", 0, KEY_READ, &hkey);

	if (stat == ERROR_SUCCESS)
	{
		DWORD dwSize = MAX_PATH;

		RegQueryValueEx(hkey, L"ProcessName", NULL, NULL, (BYTE *)szPName, &dwSize);

		dwSize = sizeof(DWORD);
		RegQueryValueEx(hkey, L"NumCards", NULL, NULL, (BYTE *)&dwNumCardsPerSec, &dwSize);

		if (dwNumCardsPerSec == 0)
		{
			dwNumCardsPerSec = 100;
		}

		dwCardsPerTic = dwNumCardsPerSec / 5;
	}
	else
	{
		MessageBox(NULL, L"Can not load registry settings. Run Skimbad Settings.", L"Error", MB_OK | MB_ICONEXCLAMATION);
		return 0;
	}

	std::vector<std::string> firstnames;
	std::vector<std::string> lastnames;
	std::vector<WCHAR*> uniptr;
	std::vector<char*> ansiptr;

	LoadNamesRC(IDR_FIRSTNAMES, firstnames);
	LoadNamesRC(IDR_LASTNAMES, lastnames);

	//initialize pointers
	for (int x = 0; x < dwNumCardsPerSec; x++)
	{
		uniptr.push_back(NULL);
		ansiptr.push_back(NULL);
	}

	srand((unsigned int)time(0)); // Seed it

	//Monitor target process and die when asked to
	while (mmStatus->SettingsCommand != WD_KILL_ALL)
	{
		dwPid = FindExePid(szPName);

		//update status time
		mmStatus->LastUpdate = timeGetTime();

		//Check watchdogs
		WatchDogCheck(mmStatus);

		//If process not running, wait for it
		while (dwPid == 0 && (mmStatus->SettingsCommand != WD_KILL_ALL))
		{
			dwPid = FindExePid(szPName);
			Sleep(50);

			//update status time
			mmStatus->LastUpdate = timeGetTime();
			WatchDogCheck(mmStatus);
		}

		//GetWindowThreadProcessId(hWnd, &pid);
		HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, 0, dwPid);
		DWORD dwStatus;

		GetExitCodeProcess(hProcess, &dwStatus);

		//Go until target process is no longer active or kill signal is given
		while (dwStatus == STILL_ACTIVE && (mmStatus->SettingsCommand != WD_KILL_ALL))
		{
			//update status time
			mmStatus->LastUpdate = timeGetTime();
			WatchDogCheck(mmStatus);


			// Generate unicode card data
			for (int x = 0; x < dwCardsPerTic; x++)
			{
				uniptr[x] = (WCHAR*)VirtualAllocEx(hProcess, NULL, sizeof(WCHAR) * MAX_DATA_SIZE, MEM_COMMIT, PAGE_READWRITE);
				GenerateCardDataW(hProcess, uniptr[x], firstnames, lastnames);
				ansiptr[x] = (char*)VirtualAllocEx(hProcess, NULL, sizeof(char) * MAX_DATA_SIZE, MEM_COMMIT, PAGE_READWRITE);
				GenerateCardDataA(hProcess, ansiptr[x], firstnames, lastnames);
			}

			Sleep(200);

			//Free allocated memory
			for (int x = 0; x < dwCardsPerTic; x++)
			{
				VirtualFreeEx(hProcess, uniptr[x], 0, MEM_RELEASE);
				VirtualFreeEx(hProcess, ansiptr[x], 0, MEM_RELEASE);
			}

			//Check process status
			GetExitCodeProcess(hProcess, &dwStatus);
		}

		if (dwStatus != STILL_ACTIVE)
		{
			//MessageBox(NULL, L"Target program is no longer available. Waiting for it to restart.", L"Skimbad", MB_OK);
		}

		CloseHandle(hProcess);
	}
	
	CloseSkimMap(hMapFile, mmStatus);
	return 0;
}
